package lava.engine;

/**
 * Represents a fluid being manipulated on chip.  Fluids are
 * immutable.
 */
public interface Fluid {
}
