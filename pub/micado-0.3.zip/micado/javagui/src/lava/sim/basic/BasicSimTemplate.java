package lava.sim.basic;

import lava.vm.*;
import lava.sim.*;
import lava.sim.basic.*;

/**
 * This will be dynamically modified to suit a given VM.
 */
public abstract class BasicSimTemplate extends BasicSim {
    /**
     * Can't take any arguments since we're invoking with reflection.
     */
    public BasicSimTemplate() {
	// this.vm = new Template();
    }

// INSERT METHODS HERE
}
