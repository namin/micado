micado 1.3

Thank you for downloading Micado, the AutoCAD plug-in for programmable microfluidics.

See INSTALL.txt for installation instructions.

Please visit http://cag.csail.mit.edu/micado/ for the documentation and for the latest release.

Please send feedback to namin@mit.edu.